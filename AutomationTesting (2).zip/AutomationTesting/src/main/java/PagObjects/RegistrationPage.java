package PagObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegistrationPage {
	
	@FindBy(name="firstName")
	public WebElement FirstName; 
	
	@FindBy(name="lastName")
	public WebElement LastName; 
	
		
}
