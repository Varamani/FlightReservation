package DataReader;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class XlsReader {
	public static void main(String[] args) throws IOException
	{
	    //XSSF - .xlsx
		//HSSF-  .xls
		
		FileInputStream fl= new FileInputStream("C:\\Users\\User\\eclipse-workspace\\AutomationTesting\\src\\main\\resources\\TestData\\TestData.xls");
		HSSFWorkbook wb = new HSSFWorkbook(fl);
		HSSFSheet sheet = wb.getSheet("Sheet1");
		HSSFRow row = sheet.getRow(1);
		HSSFCell cell= row.getCell(0);
		System.out.println(cell);
		
	}

}
