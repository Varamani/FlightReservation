package DataReader;

import org.testng.annotations.Test;

public class SampleClass {

	@Test
	public void method()
	{
		System.out.println("Swetha Lakshmi");
	}
}
