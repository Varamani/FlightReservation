package Base;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


public class TestBase {
	
	public static WebDriver driver=null;
	public static Properties prop= null;
	
	@Parameters({"browsername","AppUrl"})
	@Test()
	public static void setup(String browsername,String App_Url) throws IOException
	{		
	   if(browsername.equalsIgnoreCase("chrome"))
		{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\User\\eclipse-workspace\\AutomationTesting\\src\\main\\resources\\Drivers\\ChromeDriver\\chromedriver.exe");
	    driver = new ChromeDriver();
		}else if(browsername.equalsIgnoreCase("IE"))
		{
		System.setProperty("webdriver.ie.driver", "C:\\Users\\User\\eclipse-workspace\\AutomationTesting\\src\\main\\resources\\Drivers\\IEDriver\\IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		}else if(browsername.equalsIgnoreCase("Firefox"))
		{
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\User\\eclipse-workspace\\AutomationTesting\\src\\main\\resources\\Drivers\\FirefoxDriver\\geckodriver.exe");
		driver = new FirefoxDriver();
		}
		
		driver.manage().window().maximize();
	    driver.get(App_Url);
	    
	    driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	}
	
/*	@Test(priority=2,groups="A")
	public void registration() throws IOException
	{
		FileInputStream fi= new FileInputStream("C:\\Users\\User\\eclipse-workspace\\AutomationTesting\\src\\main\\resources\\TestData\\Test_Data.xlsx");
		XSSFWorkbook wb= new XSSFWorkbook(fi);
		XSSFSheet ws=wb.getSheet("Sheet");
		XSSFRow row=ws.getRow(1);
		String FirstName=row.getCell(0).toString();
		String LastName=row.getCell(1).toString();
		
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(FirstName);
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(LastName);
	}
	@Test(priority=3,dependsOnGroups="A")
	public static void App_exit()
	{
		driver.quit();
	}*/

}
