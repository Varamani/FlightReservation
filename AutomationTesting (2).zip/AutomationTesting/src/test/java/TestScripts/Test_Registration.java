package TestScripts;

import java.io.IOException;

import Base.TestBase;
import PagObjects.RegistrationPage;

public class Test_Registration extends TestBase{
	
	public void Register() throws IOException
	{
		RegistrationPage RP=new RegistrationPage();
		
		 setup();
		 RP.registration();
		 App_exit(); 
	}

}
